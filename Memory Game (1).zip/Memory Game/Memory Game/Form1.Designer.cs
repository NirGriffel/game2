﻿namespace Memory_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.card_1 = new System.Windows.Forms.PictureBox();
            this.card_2 = new System.Windows.Forms.PictureBox();
            this.card_3 = new System.Windows.Forms.PictureBox();
            this.card_4 = new System.Windows.Forms.PictureBox();
            this.card_5 = new System.Windows.Forms.PictureBox();
            this.card_6 = new System.Windows.Forms.PictureBox();
            this.card_7 = new System.Windows.Forms.PictureBox();
            this.card_8 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.card_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // card_1
            // 
            this.card_1.Image = global::Memory_Game.Properties.Resources.card_BACK;
            this.card_1.Location = new System.Drawing.Point(75, 12);
            this.card_1.Name = "card_1";
            this.card_1.Size = new System.Drawing.Size(200, 339);
            this.card_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card_1.TabIndex = 0;
            this.card_1.TabStop = false;
            this.card_1.Click += new System.EventHandler(this.card_Click);
            // 
            // card_2
            // 
            this.card_2.Image = global::Memory_Game.Properties.Resources.card_BACK;
            this.card_2.Location = new System.Drawing.Point(329, 12);
            this.card_2.Name = "card_2";
            this.card_2.Size = new System.Drawing.Size(200, 339);
            this.card_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card_2.TabIndex = 1;
            this.card_2.TabStop = false;
            this.card_2.Click += new System.EventHandler(this.card_Click);
            // 
            // card_3
            // 
            this.card_3.Image = global::Memory_Game.Properties.Resources.card_BACK;
            this.card_3.Location = new System.Drawing.Point(587, 12);
            this.card_3.Name = "card_3";
            this.card_3.Size = new System.Drawing.Size(200, 339);
            this.card_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card_3.TabIndex = 2;
            this.card_3.TabStop = false;
            this.card_3.Click += new System.EventHandler(this.card_Click);
            // 
            // card_4
            // 
            this.card_4.Image = global::Memory_Game.Properties.Resources.card_BACK;
            this.card_4.Location = new System.Drawing.Point(845, 12);
            this.card_4.Name = "card_4";
            this.card_4.Size = new System.Drawing.Size(200, 339);
            this.card_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card_4.TabIndex = 3;
            this.card_4.TabStop = false;
            this.card_4.Click += new System.EventHandler(this.card_Click);
            // 
            // card_5
            // 
            this.card_5.Image = global::Memory_Game.Properties.Resources.card_BACK;
            this.card_5.Location = new System.Drawing.Point(75, 381);
            this.card_5.Name = "card_5";
            this.card_5.Size = new System.Drawing.Size(200, 339);
            this.card_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card_5.TabIndex = 4;
            this.card_5.TabStop = false;
            this.card_5.Click += new System.EventHandler(this.card_Click);
            // 
            // card_6
            // 
            this.card_6.Image = global::Memory_Game.Properties.Resources.card_BACK;
            this.card_6.Location = new System.Drawing.Point(329, 381);
            this.card_6.Name = "card_6";
            this.card_6.Size = new System.Drawing.Size(200, 339);
            this.card_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card_6.TabIndex = 5;
            this.card_6.TabStop = false;
            this.card_6.Click += new System.EventHandler(this.card_Click);
            // 
            // card_7
            // 
            this.card_7.Image = global::Memory_Game.Properties.Resources.card_BACK;
            this.card_7.Location = new System.Drawing.Point(587, 381);
            this.card_7.Name = "card_7";
            this.card_7.Size = new System.Drawing.Size(200, 339);
            this.card_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card_7.TabIndex = 6;
            this.card_7.TabStop = false;
            this.card_7.Click += new System.EventHandler(this.card_Click);
            // 
            // card_8
            // 
            this.card_8.Image = global::Memory_Game.Properties.Resources.card_BACK;
            this.card_8.Location = new System.Drawing.Point(845, 381);
            this.card_8.Name = "card_8";
            this.card_8.Size = new System.Drawing.Size(200, 339);
            this.card_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.card_8.TabIndex = 7;
            this.card_8.TabStop = false;
            this.card_8.Click += new System.EventHandler(this.card_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(1127, 371);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.card_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Memory_Game.Properties.Resources.WallpaperMinimalist;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1268, 732);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.card_8);
            this.Controls.Add(this.card_7);
            this.Controls.Add(this.card_6);
            this.Controls.Add(this.card_5);
            this.Controls.Add(this.card_4);
            this.Controls.Add(this.card_3);
            this.Controls.Add(this.card_2);
            this.Controls.Add(this.card_1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.card_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox card_1;
        private System.Windows.Forms.PictureBox card_2;
        private System.Windows.Forms.PictureBox card_3;
        private System.Windows.Forms.PictureBox card_4;
        private System.Windows.Forms.PictureBox card_5;
        private System.Windows.Forms.PictureBox card_6;
        private System.Windows.Forms.PictureBox card_7;
        private System.Windows.Forms.PictureBox card_8;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

