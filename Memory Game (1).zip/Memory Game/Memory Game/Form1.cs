﻿using Memory_Game.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace Memory_Game
{
    public partial class Form1 : Form
    {


        SoundPlayer clickOff = new SoundPlayer(@"C:\Users\bengr\Desktop\MEMORY GAME\sound_clickOff.wav");
        SoundPlayer clickOn = new SoundPlayer(@"C:\Users\bengr\Desktop\MEMORY GAME\sound_clickOn.wav");
        int counter = 0;
        int cardsLeft = 4;
        PictureBox a1 = new PictureBox();
        PictureBox a2 = new PictureBox();
        public Form1()
        {
            InitializeComponent();
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
      

        private void card_Click(object sender, EventArgs e)
        {
            PictureBox pictureBox = sender as PictureBox;

            if (!IsImagesMatch(pictureBox.Image, Resources.card_BACK))
            {
                pictureBox.Image = Resources.card_BACK;
                clickOff.Play();
                HideImages();
            }

            else
            {


                if (counter == 2)
                {
                    #region //imageMatching
                    if (IsImagesMatch(a1.Image, a2.Image))
                    {
                        //MessageBox.Show("Good job im so proud");
                        if (IsImagesMatch(a1.Image,Resources.card_earth))
                        {
                            card_1.Visible = false;
                            card_4.Visible = false;
                            cardsLeft--;
                            //cards 1,4
                        }
                        //mars
                        if (IsImagesMatch(a1.Image, Resources.card_mars))
                        {
                            //cards 2,6
                            card_2.Visible = false;
                            card_6.Visible = false;
                            cardsLeft--;
                        }
                        //mercury
                        if (IsImagesMatch(a1.Image, Resources.card_mercury))
                        {
                            card_3.Visible = false;
                            card_5.Visible = false;
                            cardsLeft--;
                            //cards 3,5
                        }
                        //neptune
                        if (IsImagesMatch(a1.Image, Resources.card_neptune))
                        {
                            card_7.Visible = false;
                            card_8.Visible = false;
                            cardsLeft--;
                            //cards 7,8
                        }
                        #endregion
                    }
                    else
                    {
                        a1 = new PictureBox();
                        a2 = new PictureBox();
                    }
                    counter = 0;
                    HideImages();

                    
                }


                else
                {
                    #region //switch cases
                    switch (pictureBox.Name)
                    {
                        case "card_1":
                            {
                                pictureBox.Image = Resources.card_earth;
                                clickOn.Play();
                                counter++;
                                a1 = card_1;
                                card_1.Enabled = false;
                                break;

                            }

                        case "card_2":
                            {
                                pictureBox.Image = Resources.card_mars;
                                clickOn.Play();
                                counter++;
                                a1 = card_2;
                                card_2.Enabled = false;
                                break;
                            }
                        case "card_3":
                            {
                                pictureBox.Image = Resources.card_mercury;
                                clickOn.Play();
                                counter++;
                                a1 = card_3;
                                card_3.Enabled = false;
                                break;
                            }
                        case "card_4":
                            {
                                pictureBox.Image = Resources.card_earth;
                                clickOn.Play();
                                counter++;
                                a2 = card_4;
                                card_4.Enabled = false;
                                break;
                                
                            }
                        case "card_5":
                            {
                                pictureBox.Image = Resources.card_mercury;
                                clickOn.Play();
                                counter++;
                                a2 = card_5;
                                card_5.Enabled = false;
                                break;
                            }
                        case "card_6":
                            {
                                pictureBox.Image = Resources.card_mars;
                                clickOn.Play();
                                counter++;
                                a2 = card_6;
                                card_6.Enabled = false;
                                break;
                            }
                        case "card_7":
                            {
                                pictureBox.Image = Resources.card_neptune;
                                clickOn.Play();
                                counter++;
                                a1 = card_7;
                                card_7.Enabled = false;
                                break;
                            }
                        case "card_8":
                            {
                                pictureBox.Image = Resources.card_neptune;
                                clickOn.Play();
                                counter++;
                                a2 = card_8;
                                card_8.Enabled = false;
                                break;

                            }
                            #endregion
                    }
                }
            }
        }

        
 

        private void HideImages()
        {
                foreach (PictureBox pictureBox in this.Controls)
                {
                    pictureBox.Image = Resources.card_BACK;
                    pictureBox.Enabled = true;
            }

        }


        public bool IsImagesMatch(Image image1, Image image2)
        {
            try
            {
                //create instance or System.Drawing.ImageConverter to convert
                //each image to a byte array
                ImageConverter converter = new ImageConverter();
                //create 2 byte arrays, one for each image
                byte[] imgBytes1 = new byte[1];
                byte[] imgBytes2 = new byte[1];

                //convert images to byte array
                imgBytes1 = (byte[])converter.ConvertTo(image1, imgBytes2.GetType());
                imgBytes2 = (byte[])converter.ConvertTo(image2, imgBytes1.GetType());

                //now compute a hash for each image from the byte arrays
                System.Security.Cryptography.SHA256Managed sha = new System.Security.Cryptography.SHA256Managed();
                byte[] imgHash1 = sha.ComputeHash(imgBytes1);
                byte[] imgHash2 = sha.ComputeHash(imgBytes2);

                //now let's compare the hashes
                for (int i = 0; i < imgHash1.Length && i < imgHash2.Length; i++)
                {
                    //whoops, found a non-match, exit the loop
                    //with a false value
                    if (!(imgHash1[i] == imgHash2[i]))
                        return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            //we made it this far so the images must match
            return true;
        }



        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void counter_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
